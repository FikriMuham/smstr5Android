package com.example.smartphone.models

data class Smartphone (
    var name : String = "",
    var image : Int = 0,
    var desc : String = ""
        )